//
// Dialog class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;


/**
 *
 * @author virtajou
 *
 * Dialog class implements the CommandListener interface
 *
 */
public class Dialog implements CommandListener {

    // Define private member variables for the Dialog class
    private Controller controller;

    private Event event;

    private static Command backCommand;
    private static Command okCommand;

    private Alert yesNoAlert;

    //
    // Default constructor for the Dialog class
    //
    public Dialog( Controller controller )
    {
        this.controller = controller;
        yesNoAlert = new Alert( null, null, null, null );
        backCommand = new Command( Constants.BACK_COMMAND_LABEL, Command.BACK, 1 );
        okCommand = new Command( Constants.OK_COMMAND_LABEL, Command.OK, 1 );
        yesNoAlert.addCommand( backCommand );
        yesNoAlert.addCommand( okCommand );
        yesNoAlert.setCommandListener( this );
    }

    //
    // Initializes the dialog
    //
    //  title   - dialog title
    //
    //  message - dialog content
    //
    //  display - display object of the midlet
    //
    //  e       - dialog attributes
    //
    public void initialize( String title, String message, Display display, Event e )
    {
        this.event = e;
        yesNoAlert.setTitle( title );
        yesNoAlert.setString( message );
        display.setCurrent( yesNoAlert );
    }

    // Framework calls this method when the cellphone's keys are pressed in the Dialog
    public void commandAction( Command c, Displayable d )
    {
        // Handle the next event
        if ( c.getCommandType() == Command.OK )
        {
            System.out.println( "OK" );
            controller.handleEvent( Integer.parseInt( (String) event.getByName( "next_event_id" ) ), event );
        }

        // Go back to the original display
        if ( c.getCommandType() == Command.BACK )
        {
            System.out.println( "BACK" );
            controller.handleEvent( Integer.parseInt( (String) event.getByName( "original_event_id" ) ), event );
        }
    }
}
