//
// PIM_Exercise_1_MIDlet class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// Sovellus on toteutettu tasolle 5 ja se sisaltaa myos itsetehdyn MVC-frameworkin
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;


/**
 *
 * @author virtajou
 *
 * PIM_Exercise_1_MIDlet class inherits the MIDlet class
 * 
 */
public class PIM_Exercise_1_MIDlet extends MIDlet {

    // Define private member variables for the PIM_Exercise_1_MIDlet class
    private Model model;
    private EditView editView;
    private AppendView appendView;
    private ListMenu listMenu;
    private DeleteMenu deleteMenu;
    private Event e;
    private boolean first_time;


    // Constructor for the PIM_Exercise_1_MIDlet class
    public PIM_Exercise_1_MIDlet()
    {

        // Create the model and store midlet into it
        model = new Model();
        model.midlet = this;

        // Create the mainMenu and store it into the model
        model.mainMenu = new MainMenu( Constants.MAIN_MENU_TITLE, "MainMenu", Display.getDisplay( this ) );
        model.mainMenu.initialize( model );

        // Create the listMenu
        listMenu = new ListMenu( Constants.LIST_MENU_TITLE, "ListMenu", Display.getDisplay( this ) );
        listMenu.initialize( model );

        // Create the deleteMenu
        deleteMenu = new DeleteMenu( Constants.DELETE_MENU_TITLE, "DeleteMenu", Display.getDisplay( this ) );
        deleteMenu.initialize( model );

        // Create the editView
        editView = new EditView( Constants.EDIT_VIEW_TITLE, "EditView", Display.getDisplay( this ) );
        editView.initialize( model );

        // Create the appendView
        appendView = new AppendView( Constants.APPEND_VIEW_TITLE, "AppendView", Display.getDisplay( this ) );
        appendView.initialize( model );

        // Read contacts from the PIM database
        e = new Event();
        model.readContacts( e );

        first_time = true;
    }

    // Framework calls this method when the application is destroyed
    protected void destroyApp( boolean unconditional ) throws MIDletStateChangeException
    {

    }

    // Framework calls this method when the application is in paused state
    protected void pauseApp()
    {

    }

    // Framework calls this method when the application is started
    protected void startApp() throws MIDletStateChangeException
    {

        // Activate the mainMenu and display the return message of model.readContacts() method
        // if this is the first call of startApp() method
        if ( first_time == true )
        {
            model.mainMenu.activate( Constants.INFO_STRING, (String) e.getByName( "message" ) );
            first_time = false;
        }
        else
        {
            model.mainMenu.activate( null, null );
        }
    }

    // Framework calls this method when the application exits
    public void exitApp()
    {

        try
        {
            destroyApp( true );
        }
        catch ( MIDletStateChangeException ex )
        {
            ex.printStackTrace();
        }
        notifyDestroyed();
    }
}
