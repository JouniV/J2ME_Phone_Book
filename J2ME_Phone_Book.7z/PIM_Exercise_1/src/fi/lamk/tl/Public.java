//
// Public class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//

// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.ImageItem;
import javax.microedition.lcdui.StringItem;

/**
 *
 * @author virtajou
 *
 * Public class
 * 
 */
public class Public  {

    // One meter in pixels
    //  - http://muunnin.com/kertoimet.php?id=pituus&perus=px&jarjestys=1
    private static final double ONE_METER_IN_PIXELS = 3794.0;


    // Appends StringItem into the Form
    public static void appendStringItemToForm( String itemName, String stringItem, int layout, Form form, int row  )
    {

        // Create a new StringItem
        StringItem si = new StringItem( itemName, stringItem );

        // Set the StringItem's layout
        si.setLayout( layout );

        // Append or insert the StringItem into Form
        if ( row == -1 )
        {
            form.append( si );
        }
        else
        {
            form.insert( row, si );
        }
    }

    //
    // Appends imageItem into the Form
    //
    public static void appendImageItemToForm( String label, Image img, int layout, String altText, Form form )
    {

        // Create a new ImageItem
        ImageItem imageItem = new ImageItem( label,  img, layout, altText );

        // Append the ImageItem "imageItem" into form
        form.append( imageItem );
    }

    //
    // Returns the value of the first argument raised to the power of the second argument
    //
    public static double raiseToPower( double a, int b )
    {
        double retVal, tmp;
        int i;

        retVal = a;

        for ( i = 1; i < b; i++ )
        {
            tmp = retVal;
            retVal = tmp * a;
        }

        return retVal;
    }

    //
    // Converts pixels to meters
    //  - http://mobilepit.com/08/how-to-round-floating-point-number-double-to-2-decimal-points-in-j2me-javame.html
    //
    // pixels   - Pixels to convert
    // decimals - decimals in the converted result
    //
    public static double convertPixelsToMeters( double pixels, int decimals )
    {
        double retVal;
        double d1, d2, d3;

        d3 = raiseToPower( 10.0, decimals );
        d1 = 0.5 / d3;
        d2 = d3;

        retVal = (double)(int) ( ( pixels / ONE_METER_IN_PIXELS + d1 ) * d2 ) / d2;

        return retVal;
    }

    //
    // Displays an alert box on the cellphone's screen
    //
    //  title   - the title of the alert box
    //
    //  message - the content of the alert box
    //
    public static void showMessage( String title, String message, Display display )
    {
        Alert alert = new Alert( title, message, null, null );
	alert.setTimeout( Alert.FOREVER );
 	alert.setType( AlertType.INFO );
	display.setCurrent( alert );
    }
}
