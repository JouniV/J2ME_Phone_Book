//
// ListMenuBase class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//

// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

/**
 *
 * @author virtajou
 *
 * Class ListMenuBase inherits the Menu class and iplements the CommandListener and Observer interfaces
 */
public class ListMenuBase extends Menu implements CommandListener, Observer {

    // Define protected member variables for the ListMenuBase class
    protected Command exitCommand;

    protected int model_size;

    private String s, t;

    //
    // Default constructor for the ListMenuBase class
    //
    public ListMenuBase( String title, String name, Display display )
    {
        super( title, name, display );

        // Add commands into the menu
        exitCommand = new Command( Constants.EXIT_COMMAND_LABEL, Command.EXIT, 1 );
        this.addCommand( exitCommand );

        // Set this class as a CommandListener implementer
        this.setCommandListener( this );
    }

    //
    // Initializes the Menu
    //
    //  model   - the model of the application
    //
    public void initialize( Model model )
    {
        super.initialize( model );

        // Connect the Menu to the Model
        model.attachObserver( this, name );
    }

    public void commandAction( Command c, Displayable d )
    {

    }

    //
    // Returns the contact count of the model
    //
    public int getModelSize()
    {

        // Get the contact count of the model
        event = new Event();
        event.setByName( "EventName", "GetModelSize" );
        controller.handleEvent( Event.GET_CONTACT_SEQUENCE, event );
        return Integer.parseInt( (String) event.getByName( "model_size" ) );
    }

    //
    // Returns the model contact at the specified index position
    //
    public Contact getModelContact( int index )
    {

        // Get contact from the model
        event.setByName( "index", index + "" );
        controller.handleEvent( Event.GET_CONTACT, event );
        return (Contact) event.getByName( "contact" );
    }

    //
    // Returns the current contact index of the model
    //
    public int getModelIndex()
    {

        // Get the current contact index of the model
        event = new Event();
        event.setByName( "EventName", "GetModelIndex" );
        controller.handleEvent( Event.GET_CONTACT_SEQUENCE, event );
        return Integer.parseInt( (String) event.getByName( "contact_index" ) );
    }

    //
    // Appends or sets the contact information of the menu
    //
    //  contact - contact information to set
    //
    //  row     - menu row to set if unequal than -1, otherwise appends a new row
    //
    //
    public void appendMenuItem( Contact contact, int row )
    {

        // Build the menu row

        // Clear the string
        s = "";

        // Copy the first name to string if it exists
        t = contact.getFirst_name();
        if ( t.length() > 0 )
            s = s + t;

        // Concatenate the last name to string if it exists
        t = contact.getLast_name();
        if ( t.length() > 0 )
        {
            if ( s.length() > 0 )
            {
                s = s + " ";
            }
            s = s + t;
        }

        // Copy the company name to string if it is still empty
        if ( s.length() == 0 )
        {
            s = contact.getCompany();
        }

        // Append or set the menu row
        if ( row == -1 )
        {
            this.append( s, null );            
        }
        else
        {
            this.set( row, s, null );
        }
    }

    //
    // Updates the content of the menu
    //
    public void update( Observable o, String arg )
    {

        // Get all contacts from the model and append them into the menu
        if ( arg.equals( "readContacts" ) == true )
        {
            // Delete all items of the menu
            this.deleteAll();

            // Get the contact count of the model
            model_size = getModelSize();

            for ( i = 0; i < model_size; i++ )
            {
                // Get contact from the model and append it to menu
                appendMenuItem( getModelContact( i ), -1 );
            }
        }

        if ( arg.equals( "setContact" ) == true )
        {
            i = getModelIndex();
            // this.delete( i );
            appendMenuItem( getModelContact( i ), i );
        }

        if ( arg.equals( "addContact" ) == true )
        {
            // Get the contact count of the model
            model_size = getModelSize();

            // Get the last contact from the model and append it to menu
            appendMenuItem( getModelContact( model_size - 1 ), -1 );
        }

        if ( arg.equals( "deleteContact" ) == true )
        {
            this.delete( getModelIndex() );
        }
    }
}
