//
// ListMenu class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;


/**
 *
 * @author virtajou
 *
 * ListMenu class inherits the ListMenuBase class
 */
public class ListMenu extends ListMenuBase {

    // Define private member variables for the ListMenu class
    private Command editCommand;

    //
    // Default constructor for the ListMenu class
    //
    public ListMenu( String title, String name, Display display )
    {
        super( title, name, display );

        // Add commands into the menu
        editCommand = new Command( Constants.EDIT_COMMAND_LABEL, Command.SCREEN, 1 );
        this.addCommand( editCommand );
    }

    // Framework calls this method when the cellphone's keys are pressed in the ListMenu
    public void commandAction( Command c, Displayable d )
    {

        // Display the user selected contact in editView
        if ( c == List.SELECT_COMMAND  || c == editCommand )
        {
            event = new Event();
            event.setByName( "index", this.getSelectedIndex() + "" );
            controller.handleEvent( Event.EDIT_CONTACT, event );
        }

        // Return to mainMenu
        if ( c == exitCommand )
        {
            event = new Event();
            event.setByName( "EventName", "DisplayMenu" );
            controller.handleEvent( Event.DISPLAY_MENU, event );
        }
    }

    //
    // Updates the content of the menu
    //
    public void update( Observable o, String arg )
    {
        super.update( o, arg );
    }
}
