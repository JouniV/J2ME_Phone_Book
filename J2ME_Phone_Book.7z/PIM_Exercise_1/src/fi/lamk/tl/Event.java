//
// Event class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import java.util.Hashtable;


/**
 *
 * @author virtajou
 *
 * Event class
 *
 */
public class Event {

    // Event attributes
    private Hashtable events;

    // Menu event strings
    public static String EVENT_STRINGS[] =
    {
        "Edit contacts",
        "Add Contact",
        "Delete contact",
        "Exit"
    };

    // Menu event IDs
    public static final int DISPLAY_LIST_CONTACTS_MENU = 0;
    public static final int DISPLAY_ADD_CONTACT_VIEW = 1;
    public static final int DISPLAY_DELETE_CONTACT_MENU = 2;
    public static final int CONFIRM_EXIT_APPLICATION = 3;

    // Common event IDs
    public static final int DISPLAY_MENU = CONFIRM_EXIT_APPLICATION + 1;
    public static final int GET_CONTACT = DISPLAY_MENU + 1;
    public static final int EDIT_CONTACT = GET_CONTACT + 1;
    public static final int GET_CURRENT_CONTACT = EDIT_CONTACT + 1;
    public static final int SET_CURRENT_CONTACT = GET_CURRENT_CONTACT + 1;
    public static final int GET_CONTACT_SEQUENCE = SET_CURRENT_CONTACT + 1;
    public static final int ADD_CONTACT = GET_CONTACT_SEQUENCE + 1;
    public static final int CONFIRM_EVENT = ADD_CONTACT + 1;
    public static final int DELETE_CONTACT = CONFIRM_EVENT + 1;
    public static final int CHECK_MANDATORY_FIELDS = DELETE_CONTACT + 1;
    public static final int EXIT_APPLICATION = CHECK_MANDATORY_FIELDS + 1;

    //
    // Default constructor for the Event class
    //
    public Event()
    {
        events = new Hashtable();
    }

    //
    // Returns the value to which the specified key is mapped in the events hashtable
    //
    public Object getByName( Object key )
    {
        return events.get( key );
    }

    //
    // Maps the specified key to the specified value in the events hashtable
    //
    public Object setByName( Object key, Object value )
    {
        return events.put( key, value );
    }

    //
    // Clears the events hashtable so that it contains no keys
    //
    public void clear()
    {
        events.clear();
    }
}
