//
// Contact class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;

/**
 *
 * @author virtajou
 *
 * Contact class
 *
 */
public class Contact {

    // Define private member variables for the Contact class
    private String first_name;
    private String original_first_name;
    private String last_name;
    private String original_last_name;
    private String company;
    private String original_company;
    private String address;
    private String phone;

    //
    // Default constructor for the Contact class
    //
    public Contact()
    {
        this( "", "", "", "", "" );
    }

    //
    // Constructor for the Contact class
    //
    public Contact( String first_name, String last_name, String company, String address, String phone )
    {
        setFirst_name( first_name );
        setOriginal_first_name( null );
        setLast_name( last_name );
        setOriginal_last_name( null );
        setCompany( company );
        setOriginal_company( null );
        setAddress( address );
        setPhone( phone );
    }

    /**
     * @return the first_name
     */
    public String getFirst_name()
    {
        return first_name;
    }

    /**
     * @param first_name the first_name to set
     */
    public void setFirst_name(String first_name)
    {
        this.first_name = first_name;
    }

    /**
     * @return the original_first_name
     */
    public String getOriginal_first_name()
    {
        return original_first_name;
    }

    /**
     * @param original_first_name the original_first_name to set
     */
    public void setOriginal_first_name(String original_first_name)
    {
        this.original_first_name = original_first_name;
    }

    /**
     * @return the last_name
     */
    public String getLast_name()
    {
        return last_name;
    }

    /**
     * @param last_name the last_name to set
     */
    public void setLast_name(String last_name)
    {
        this.last_name = last_name;
    }

    /**
     * @return the original_last_name
     */
    public String getOriginal_last_name()
    {
        return original_last_name;
    }

    /**
     * @param original_last_name the original_last_name to set
     */
    public void setOriginal_last_name(String original_last_name)
    {
        this.original_last_name = original_last_name;
    }

    /**
     * @return the company
     */
    public String getCompany()
    {
        return company;
    }

    /**
     * @param company the company to set
     */
    public void setCompany(String company)
    {
        this.company = company;
    }

    /**
     * @return the original_company
     */
    public String getOriginal_company()
    {
        return original_company;
    }

    /**
     * @param original_company the original_company to set
     */
    public void setOriginal_company(String original_company)
    {
        this.original_company = original_company;
    }

    /**
     * @return the address
     */
    public String getAddress()
    {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address)
    {
        this.address = address;
    }

    /**
     * @return the phone
     */
    public String getPhone()
    {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone)
    {
        this.phone = phone;
    }
}
