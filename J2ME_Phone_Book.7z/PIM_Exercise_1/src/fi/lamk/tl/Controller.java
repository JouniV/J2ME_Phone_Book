//
// Controller class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Display;


/**
 *
 * @author virtajou
 *
 * Controller class
 *
 */
public class Controller {

    // Define private member variables for the Controller class
    private static Controller instance = null;
    private Display display;
    private Model model;
    private View view;
    private Menu menu;
    private String s;
    private Dialog dialog;

    //
    // Default constructor for the Controller class
    //
    public Controller()
    {
        dialog = new Dialog( this );
    }

    //
    // Initializes the controller
    //
    //  display - display object of the midlet
    //
    //  model   - the model of the application
    //
    //  view    - the initializer view
    //
    public void initialize( Display display, Model model, View view )
    {
        this.display = display;
        this.model = model;
        this.view = view;
    }

    //
    // Initializes the controller
    //
    //  display - display object of the midlet
    //
    //  model   - the model of the application
    //
    //  menu    - the initializer menu
    //
    public void initialize( Display display, Model model, Menu menu )
    {
        this.display = display;
        this.model = model;
    }

    //
    // Creates a singleton instance of Controller class and returns it
    //
    public static synchronized Controller getInstance()
    {
        if( instance == null )
        {
            instance = new Controller();
        }

        return instance;
    }

    //
    // Handles the controller event and returns true if the handling was successful, otherwise false
    //
    //  eventID - event id to handle
    //
    //  e       - event attributes
    //
    public boolean handleEvent( int eventID, Event e )
    {
        boolean retVal = true;

        switch( eventID )
        {
            case Event.DISPLAY_LIST_CONTACTS_MENU:
                if ( model.getSize() > 0 )
                {
                    menu = (Menu) model.getObserver( "ListMenu" );
                    menu.activate();
                }
                break;

            case Event.DISPLAY_ADD_CONTACT_VIEW:
                view = (View) model.getObserver( "AppendView" );
                view.activate();
                break;

            case Event.DISPLAY_DELETE_CONTACT_MENU:
                if ( model.getSize() > 0 )
                {
                    menu = (Menu) model.getObserver( "DeleteMenu" );
                    menu.activate();
                }
                break;

            case Event.CONFIRM_EXIT_APPLICATION:
                model.writeContacts( e );
                e.setByName( "next_event_id", Event.EXIT_APPLICATION + "" );
                e.setByName( "original_event_id", Event.DISPLAY_MENU + "" );
                dialog.initialize( Constants.INFO_STRING, (String) e.getByName( "message" ), display, e );
                break;
                
            case Event.DISPLAY_MENU:
                model.mainMenu.activate( null, null );
                break;

            case Event.GET_CONTACT:
                s = (String) e.getByName( "index" );
                e.setByName( "contact", model.getContact( Integer.parseInt( s ) ) );
                break;

            case Event.EDIT_CONTACT:
                s = (String) e.getByName( "index" );
                model.getContactNotifyObservers( Integer.parseInt( s ) );
                view = (View) model.getObserver( "EditView" );
                view.activate();
                break;

            case Event.GET_CURRENT_CONTACT:
                e.setByName( "contact", model.getContact() );
                e.setByName( "contact_index", ( model.getContactIndex() + 1 ) + "" );
                break;

            case Event.SET_CURRENT_CONTACT:
                retVal = model.setContact( (Contact) e.getByName( "contact" ) );
                break;

            case Event.GET_CONTACT_SEQUENCE:
                e.setByName( "next_contact_sequence", ( model.getSize() + 1 ) + "" );
                e.setByName( "model_size", model.getSize() + "" );
                e.setByName( "contact_index", model.getContactIndex() + "" );
                break;

            case Event.ADD_CONTACT:
                retVal = model.addContact( (Contact) e.getByName( "contact" ) );
                break;

            case Event.CONFIRM_EVENT:
                dialog.initialize( (String) e.getByName( "title" ), (String) e.getByName( "message" ), display, e );
                break;
                
            case Event.DELETE_CONTACT:
                s = (String) e.getByName( "index" );
                model.deleteContact( Integer.parseInt( s ) );
                if( model.getSize() > 0 )
                {
                    menu = (Menu) model.getObserver( "DeleteMenu" );
                    menu.activate();
                }
                else
                {
                    model.mainMenu.activate();
                }
                break;

            case Event.CHECK_MANDATORY_FIELDS:
                retVal = model.existsMandatoryFields( (Contact) e.getByName( "contact" ) );
                break;

            case Event.EXIT_APPLICATION:
                model.midlet.exitApp();
                break;
        }

        return retVal;
    }
}
