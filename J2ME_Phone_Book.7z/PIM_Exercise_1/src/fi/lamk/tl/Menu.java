//
// Menu class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.List;

/**
 *
 * @author virtajou
 *
 * Menu class inherits the List class
 *
 */
public class Menu extends List {

    // Define protected member variables for the Menu class
    protected String title;
    protected String name;
    protected Display display;
    protected Controller controller;

    protected int i;

    protected Event event;

    protected Contact contact;

    //
    // Default constructor for the Menu class
    //
    public Menu( String title, String name, Display display )
    {
        super( title, List.IMPLICIT );
        this.display = display;
        this.name = name;
    }

    //
    // Initializes the Menu
    //
    //  model   - the model of the application
    //
    public void initialize( Model model )
    {
        // Make controller
        makeController( model );
    }

    //
    // Initializes the controller of the application
    //
    //  model   - the model of the application
    //
    public void makeController( Model model )
    {
        controller = Controller.getInstance();
        controller.initialize( display, model, this );
    }

    //
    // Activates the menu with the alert box
    //
    //  title   - the title of the alert box
    //
    //  message - the content of the alert box
    //
    public void activate( String title, String message )
    {
        display( title, message );
    }

    //
    // Activates the menu
    //
    public void activate()
    {
        display( null, null );
    }

    //
    // Activates the menu
    //
    public void display( String title, String message )
    {
        display.setCurrent( this );

        // Display an alert box if the message is given
        if ( message != null )
        {
            Public.showMessage( title, message, display );
        }
    }
}
