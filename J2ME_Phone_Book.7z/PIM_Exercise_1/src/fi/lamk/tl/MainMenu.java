//
// MainMenu class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

/**
 *
 * @author virtajou
 *
 * MainMenu class inherits the Menu class and implements the CommandListener interface
 */
public class MainMenu extends Menu implements CommandListener {

    // Define private member variables for the MainMenu class
    private Command exitCommand;
    private Command selectCommand;

    private static final String EXIT_COMMAND_LABEL = "Exit";
    private static final String SELECT_COMMAND_LABEL = "Select";

    //
    // Default constructor for the MainMenu class
    //
    public MainMenu( String title, String name, Display display )
    {

        super( title, name, display );

        // Add the events into the menu
        for ( i = 0; i < Event.EVENT_STRINGS.length; i++ )
        {
            this.append( Event.EVENT_STRINGS[ i ], null );
        }

        // Add commands into the menu
        exitCommand = new Command( EXIT_COMMAND_LABEL, Command.EXIT, 1 );
        this.addCommand( exitCommand );

        selectCommand = new Command( SELECT_COMMAND_LABEL, Command.SCREEN, 1 );
        this.addCommand( selectCommand );

        // Set this class as a CommandListener implementer
        this.setCommandListener( this );
    }

    // Framework calls this method when the cellphone's keys are pressed in the DeleteMenu
    public void commandAction( Command c, Displayable d )
    {

        // Handle the selected menu event
        if ( c == List.SELECT_COMMAND  || c == selectCommand )
        {
            event = new Event();
            event.setByName( "EventName", "MenuEvent" );
            controller.handleEvent( this.getSelectedIndex(), event );
        }

        // Display the exit from the application dialog to the user
        if ( c == exitCommand )
        {
            event = new Event();
            event.setByName( "EventName", "ConfirmExitApplication" );
            controller.handleEvent( Event.CONFIRM_EXIT_APPLICATION, event );
        }
    }
}
