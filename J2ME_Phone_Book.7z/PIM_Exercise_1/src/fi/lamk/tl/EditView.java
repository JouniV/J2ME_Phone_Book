//
// EditView class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;


/**
 *
 * @author virtajou
 *
 * EditView class inherits the EditViewBase class
 *
 */
public class EditView extends EditViewBase {

    //
    // Default constructor for the EditView class
    //
    public EditView( String title, String name, Display display )
    {
        super( title, name, display );

        contact = new Contact();
    }

    // Framework calls this method when the cellphone's keys are pressed in the EditView
    public void commandAction( Command c, Displayable d )
    {

        // Set the current contact data in model if mandatory fields exist
        // Display an error message to the user if the contact already exists
        if ( c == saveCommand && checkMandatoryFields() == true )
        {
            contact.setFirst_name( first_name_field.getString() );
            contact.setLast_name( last_name_field.getString() );
            contact.setCompany( company_name_field.getString() );
            contact.setAddress( address_field.getString() );
            contact.setPhone( phone_field.getString() );

            event = new Event();
            event.setByName( "contact", contact );

            if ( controller.handleEvent( Event.SET_CURRENT_CONTACT, event ) == true )
            {
                Public.showMessage( Constants.INFO_STRING, Constants.CONTACT_SAVED_STRING, display );
            }
            else
            {
                Public.showMessage( Constants.ERROR_STRING, Constants.CONTACT_ALREADY_EXISTS_STRING, display );
            }
        }

        // Return to the listMenu
        if ( c == exitCommand )
        {
            event = new Event();
            event.setByName( "EventName", "ListContacts" );
            controller.handleEvent( Event.DISPLAY_LIST_CONTACTS_MENU, event );
        }
    }

    public void update( Observable o, String arg )
    {

        // Get the current contact data from model and display it in this view
        if ( arg.equals( "getContactNotifyObservers" ) == true )
        {
            event = new Event();
            event.setByName( "EventName", "GetContact" );
            controller.handleEvent( Event.GET_CURRENT_CONTACT, event );

            first_name_field.setString( ( (Contact) event.getByName( "contact" ) ).getFirst_name() );
            last_name_field.setString( ( (Contact) event.getByName( "contact" ) ).getLast_name() );
            company_name_field.setString( ( (Contact) event.getByName( "contact" ) ).getCompany() );
            address_field.setString( ( (Contact) event.getByName( "contact" ) ).getAddress() );
            phone_field.setString( ( (Contact) event.getByName( "contact" ) ).getPhone() );

            super.update( o, (String) event.getByName( "contact_index" ) );
        }
    }

}
