/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fi.lamk.tl;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Item;

/**
 *
 * @author virtajou
 */
public class ListView extends View implements CommandListener, Observer {

    private Command exitCommand;

    private int model_size;

    private int items_per_contact;


    public ListView( String title, String name, Display display )
    {
        super( title, name, display );

        exitCommand = new Command( Constants.EXIT_COMMAND_LABEL, Command.EXIT, 1 );
        this.addCommand( exitCommand );

        this.setCommandListener( this );
    }

    public void commandAction(Command c, Displayable d)
    {

        if ( c == exitCommand )
        {
            event = new Event();
            event.setByName( "EventName", "DisplayMenu" );
            controller.handleEvent( Event.DISPLAY_MENU, event );
        }
    }

    public int getModelSize()
    {

        // Get the contact count of the model
        event = new Event();
        event.setByName( "EventName", "GetModelSize" );
        controller.handleEvent( Event.GET_CONTACT_SEQUENCE, event );
        return Integer.parseInt( (String) event.getByName( "model_size" ) );
    }

    public Contact getModelContact( int index )
    {

        // Get contact from the model
        event.setByName( "index", index + "" );
        controller.handleEvent( Event.GET_CONTACT, event );
        return (Contact) event.getByName( "contact" );
    }

    public int getModelIndex()
    {

        // Get the current contact index of the model
        event = new Event();
        event.setByName( "EventName", "GetModelIndex" );
        controller.handleEvent( Event.GET_CONTACT_SEQUENCE, event );
        return Integer.parseInt( (String) event.getByName( "contact_index" ) );
    }

    public void appendViewItem( Contact contact, int row )
    {

        items_per_contact = 0;
        Public.appendStringItemToForm
        (
            "",
            Constants.DASH_LINE_LONG,
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            row
        );
        items_per_contact++;

        Public.appendStringItemToForm
        (
            "",
            contact.getFirst_name() + " " + contact.getLast_name() + "\n",
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            ( row == -1 ) ? row : row + 1
        );
        items_per_contact++;

        Public.appendStringItemToForm
        (
            "",
            contact.getPhone(),
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            ( row == -1 ) ? row : row + 4
        );
        items_per_contact++;

        /* Public.appendStringItemToForm
        (
            "",
            Constants.FIRST_NAME_STRING + contact.getFirst_name() + "\n",
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            ( row == -1 ) ? row : row + 1
        );
        items_per_contact++;

        Public.appendStringItemToForm
        (
            "",
            Constants.LAST_NAME_STRING + contact.getLast_name() + "\n",
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            ( row == -1 ) ? row : row + 2
        );
        items_per_contact++;

        Public.appendStringItemToForm
        (
            "",
            Constants.ADDRESS_STRING + contact.getAddress() + "\n",
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            ( row == -1 ) ? row : row + 3
        );
        items_per_contact++;

        Public.appendStringItemToForm
        (
            "",
            Constants.PHONE_STRING + contact.getPhone() + "\n",
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            ( row == -1 ) ? row : row + 4
        );
        items_per_contact++; */
    }

    public void update( Observable o, String arg )
    {

        // Get all contacts from the model and append them into the view
        /* if ( arg.equals( "readContacts" ) == true )
        {
            // Delete all items of the view
            this.deleteAll();

            // Get the contact count of the model
            model_size = getModelSize();

            for ( i = 0; i < model_size; i++ )
            {
                appendViewItem( getModelContact( i ), -1 );
            }
        }

        if ( arg.equals( "addContact" ) == true )
        {
            // Get the contact count of the model
            model_size = getModelSize();

            // Get the last contact from the model and append it to view
            appendViewItem( getModelContact( model_size - 1 ), -1 );
        }

        if ( arg.equals( "deleteContact" ) == true )
        {
            j = getModelIndex() * items_per_contact;

            for ( i = 0; i < items_per_contact; i++ )
            {
                this.delete( j );
            }
        } */
    }

}
