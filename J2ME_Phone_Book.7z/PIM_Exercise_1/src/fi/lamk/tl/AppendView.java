//
// AppendView class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

/**
 *
 * @author virtajou
 *
 * AppendView class inherits the EditViewBase class
 */
public class AppendView extends EditViewBase {

    //
    // Default constructor for the AppendView class
    //
    public AppendView( String title, String name, Display display )
    {
        super( title, name, display );
    }

    // Framework calls this method when the cellphone's keys are pressed in the AppendView
    public void commandAction( Command c, Displayable d )
    {

        // Add the new contact into the model if mandatory fields exist
        // Display an error message to the user if the contact already exists
        if ( c == saveCommand  && checkMandatoryFields() == true )
        {
            contact = new Contact();
            contact.setFirst_name( first_name_field.getString() );
            contact.setLast_name( last_name_field.getString() );
            contact.setCompany( company_name_field.getString() );
            contact.setAddress( address_field.getString() );
            contact.setPhone( phone_field.getString() );

            event = new Event();
            event.setByName( "contact", contact );

            if ( controller.handleEvent( Event.ADD_CONTACT, event ) == true )
            {
                Public.showMessage( Constants.INFO_STRING, Constants.CONTACT_ADDED_STRING, display );
            }
            else
            {
                Public.showMessage( Constants.ERROR_STRING, Constants.CONTACT_ALREADY_EXISTS_STRING, display );
            }
        }

        // Return to the mainMenu
        if ( c == exitCommand )
        {
            event = new Event();
            event.setByName( "EventName", "DisplayMenu" );
            controller.handleEvent( Event.DISPLAY_MENU, event );
        }
    }

    public void update( Observable o, String arg )
    {

        // Clear the view fields
        first_name_field.setString( "" );
        last_name_field.setString( "" );
        company_name_field.setString( "" );
        address_field.setString( "" );
        phone_field.setString( "" );

        // Get the sequence for the new contact and display it in the view title
        event = new Event();
        event.setByName( "EventName", "GetContactSequence" );
        controller.handleEvent( Event.GET_CONTACT_SEQUENCE, event );

        super.update( o, (String) event.getByName( "next_contact_sequence" ) );
    }

}
