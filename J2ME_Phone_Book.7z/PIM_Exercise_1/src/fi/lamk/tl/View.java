//
// View class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Form;


/**
 *
 * @author virtajou
 *
 * View class inherits the Form class
 */
public class View extends Form {

    // Define protected member variables for the View class
    protected String title;
    protected String name;
    protected Display display;
    protected Controller controller;

    protected Event event;

    protected int i, j;

    protected Contact contact;
    
    //
    // Default constructor for the View class
    //
    public View( String title, String name, Display display )
    {
        super( title );
        this.title = title;
        this.name = name;
        this.display = display;
    }

    //
    // Initializes the view
    //
    //  model   - the model of the application
    //
    public void initialize( Model model )
    {
        // Make controller
        makeController( model );

        // Connect the View to the Model
        model.attachObserver( this, name );
    }

    //
    // Initializes the controller of the application
    //
    //  model   - the model of the application
    //
    public void makeController( Model model )
    {
        controller = Controller.getInstance();
        controller.initialize( display, model, this );
    }

    //
    // Activates the view
    //
    public void activate()
    {
        display();
    }

    //
    // Activates the view
    //
    public void display()
    {
        display.setCurrent( this );
    }
}
