//
// DeleteMenu class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

/**
 *
 * @author virtajou
 *
 * DeleteMenu class inherits the ListMenuBase class
 *
 */
public class DeleteMenu extends ListMenuBase {

    // Define private member variables for the DeleteMenu class
    private Command deleteCommand;

    //
    // Default constructor for the DeleteMenu class
    //
    public DeleteMenu( String title, String name, Display display )
    {
        super( title, name, display );

        // Add commands into the view
        deleteCommand = new Command( Constants.DELETE_COMMAND_LABEL, Command.SCREEN, 1 );
        this.addCommand( deleteCommand );
    }

    // Framework calls this method when the cellphone's keys are pressed in the DeleteMenu
    public void commandAction( Command c, Displayable d )
    {

        // Delete the selected contact if the user confirmed the delete action, otherwise
        // return to the deleteMenu
        if ( c == List.SELECT_COMMAND  || c == deleteCommand )
        {
            event = new Event();
            event.setByName( "index", this.getSelectedIndex() + "" );
            event.setByName( "title", "Confirmation" );
            event.setByName( "message", Constants.DELETE_CONFIRM_STRING + " " + this.getString( this.getSelectedIndex() ) + "?" );
            event.setByName( "original_event_id", Event.DISPLAY_DELETE_CONTACT_MENU + "" );
            event.setByName( "next_event_id", Event.DELETE_CONTACT + "" );
            controller.handleEvent( Event.CONFIRM_EVENT, event );
        }

        // Return to the mainMenu
        if ( c == exitCommand )
        {
            event = new Event();
            event.setByName( "EventName", "DisplayMenu" );
            controller.handleEvent( Event.DISPLAY_MENU, event );
        }
    }

    //
    // Update the content of the DeleteMenu
    //
    public void update( Observable o, String arg )
    {
        super.update( o, arg );
    }
}
