/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fi.lamk.tl;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

/**
 *
 * @author virtajou
 */
public class Dialog2 implements CommandListener {

    private Controller controller;

    private Event event;

    private static Command softKey1;
    private static Command softKey2;

    private Alert yesNoAlert;

    public Dialog2( String title, String message, Display display )
    {

        yesNoAlert = new Alert( title, message, null, null );
        softKey1 = new Command("No", Command.BACK, 1);
        softKey2 = new Command("Yes", Command.OK, 1);
        yesNoAlert.addCommand(softKey1);
        yesNoAlert.addCommand(softKey2);
        display.setCurrent( yesNoAlert );
        yesNoAlert.setCommandListener( this );
    }

    public void commandAction( Command c, Displayable d )
    {
        // Handle the next event
        if ( c.getCommandType() == Command.OK )
        {
            System.out.println( "OK" );
            // controller.handleEvent( Integer.parseInt( (String) event.getByName( "next_event_id" ) ), event );
        }

        // Go back to the original display
        if ( c.getCommandType() == Command.BACK )
        {
            System.out.println( "BACK" );
            // controller.handleEvent( Integer.parseInt( (String) event.getByName( "original_event_id" ) ), event );
        }
    }
}

