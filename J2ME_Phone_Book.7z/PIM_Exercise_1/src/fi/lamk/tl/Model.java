//
// Model class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import java.util.Enumeration;
import java.util.Vector;
import javax.microedition.pim.ContactList;
import javax.microedition.pim.PIM;
import javax.microedition.pim.PIMException;
import javax.microedition.pim.PIMItem;


/**
 *
 * @author virtajou
 *
 * Model class inherits the Observable class
 * 
 */
public class Model extends Observable {

    // Define public member variables for the Model class
    public MainMenu mainMenu;
    public PIM_Exercise_1_MIDlet midlet;

    // Define private member variables for the Model class
    private Vector contacts;
    private Contact contact;
    private Contact contact_tmp;
    private int index;
    private int i;
    private String s;

    //
    // Default constructor for the Model class
    //
    public Model()
    {
        contacts = new Vector();
    }

    //
    // Returns the number of components in contacts vector
    //
    public int getSize()
    {
        return contacts.size();
    }

    //
    // Returns the component at the specified index in contacts vector
    //
    public Contact getContact( int index )
    {
        return (Contact) contacts.elementAt( index );
    }

    //
    // Returns the current contact from contacts vector
    //
    public Contact getContact()
    {
        return contact;
    }

    //
    // Reads the component at the specified index in contacts vector and stores it into member variable
    //
    public void getContactNotifyObservers( int index )
    {
        this.index = index;
        contact = getContact( index );
        notifyObservers( "getContactNotifyObservers" );
    }

    //
    // Sets the current contact in contact vector
    //
    public boolean setContact( Contact contact )
    {
        boolean retVal = false;

        if ( existsContact( contact ) == false )
        {
            this.contact.setFirst_name( contact.getFirst_name() );
            this.contact.setLast_name( contact.getLast_name() );
            this.contact.setCompany( contact.getCompany() );
            this.contact.setAddress( contact.getAddress() );
            this.contact.setPhone( contact.getPhone() );
            retVal = true;
            notifyObservers( "setContact" );
        }

        return retVal;
    }

    //
    // Adds the specified component to the end of contact vector
    //
    public boolean addContact( Contact contact )
    {
        boolean retVal = false;

        index = getSize();

        if ( existsContact( contact ) == false )
        {
            contacts.addElement( contact );
            retVal = true;
            notifyObservers( "addContact" );
        }

        return retVal;
    }

    //
    // Deletes the component at the specified index in contacts vector
    //
    public void deleteContact( int index )
    {
        this.index = index;
        contacts.removeElementAt( index );
        notifyObservers( "deleteContact" );
    }

    //
    // Returns true if the contact exists in contacts vector, otherwise false
    //
    public boolean existsContact( Contact contact )
    {
        boolean retVal = false;

        for ( i = 0; i < getSize(); i++ )
        {
            contact_tmp = getContact( i );

            if ( contact.getFirst_name().length() > 0 || contact.getLast_name().length() > 0 )
            {
                if ( contact_tmp.getFirst_name().toUpperCase().equals( contact.getFirst_name().toUpperCase() ) == true &&
                     contact_tmp.getLast_name().toUpperCase().equals( contact.getLast_name().toUpperCase() ) == true && i != index )
                {
                    retVal = true;
                    break;
                }
            }
            else
            {
                if ( contact_tmp.getCompany().toUpperCase().equals( contact.getCompany().toUpperCase() ) == true &&
                     contact_tmp.getFirst_name().length() == 0 && contact_tmp.getLast_name().length() == 0 && i != index )
                {
                    retVal = true;
                    break;
                }
            }
       }
        
        return retVal;
    }

    //
    // Returns true if the mandatory fields exists in contact, otherwise false
    //
    public boolean existsMandatoryFields( Contact contact )
    {
        boolean retVal = true;

        if ( contact.getFirst_name().length() == 0 &&
             contact.getLast_name().length() == 0 &&
             contact.getCompany().length() == 0 )
        {
            retVal = false;
        }
        
        return retVal;
    }

    //
    // Returns the current contact index of contacts vector
    //
    public int getContactIndex()
    {
        return index;
    }

    //
    // Copies values from the PIM contact to model contact
    //
    private void copyFromPIMContact( javax.microedition.pim.Contact PIMcontact, Contact contact )
    {
        String[] PIMname;
        String[] PIMaddress;

        // Clear the model contact original fields
        contact.setOriginal_first_name( "" );
        contact.setOriginal_last_name( "" );
        contact.setOriginal_company( "" );

        // Copy the first name and the last name if they exist
        if ( PIMcontact.countValues( javax.microedition.pim.Contact.NAME ) > 0 )
        {
            PIMname = PIMcontact.getStringArray( javax.microedition.pim.Contact.NAME, 0 );

            s = PIMname[ javax.microedition.pim.Contact.NAME_GIVEN ];
            if ( s != null )
            {
                contact.setFirst_name( s );
                contact.setOriginal_first_name( s );
            }

            s = PIMname[ javax.microedition.pim.Contact.NAME_FAMILY ];
            if ( s != null )
            {
                contact.setLast_name( s );
                contact.setOriginal_last_name( s );
            }
        }

        // Copy the company name if it exists
        if ( PIMcontact.countValues( javax.microedition.pim.Contact.ORG ) > 0 )
        {
            s = PIMcontact.getString( javax.microedition.pim.Contact.ORG, 0 );
            if ( s != null )
            {
                contact.setCompany( s );
                contact.setOriginal_company( s );
            }
        }

        // Copy the address if it exists
        if ( PIMcontact.countValues( javax.microedition.pim.Contact.ADDR ) > 0 )
        {
            PIMaddress = PIMcontact.getStringArray( javax.microedition.pim.Contact.ADDR, 0 );

            s = PIMaddress[ javax.microedition.pim.Contact.ADDR_STREET ];
            if ( s != null )
            {
                contact.setAddress( s );
            }
        }

        // Copy the phone number if it exists
        if ( PIMcontact.countValues( javax.microedition.pim.Contact.TEL ) > 0 )
        {
            s = PIMcontact.getString( javax.microedition.pim.Contact.TEL, 0 );
            if ( s != null )
            {
                contact.setPhone( s );
            }
        }
    }

    //
    // Reads contacts from the PIM database and returns 0 if the reading was successful, otherwise 1
    // Returns the status message of reading in the Event parameter
    //
    public int readContacts( Event e )
    {
        ContactList PIMcontact_list = null;
        javax.microedition.pim.Contact PIMcontact;
        Enumeration PIMcontacts = null;
        String[] PIMname = null;
        String[] PIMaddress = null;
        int retVal = 0;


        e.setByName( "message" , Constants.PIM_DATABASE_READ_SUCCESSFUL );
    
        // Open the PIM contact database
        try
        {
            PIMcontact_list = (ContactList) PIM.getInstance().openPIMList
            (
                PIM.CONTACT_LIST,
                PIM.READ_ONLY
            );
        }
        catch ( PIMException ex )
        {
            e.setByName( "message", Constants.PIM_DATABASE_OPENING_ERROR + " " + ex.toString() );
            retVal = 1;
        }

        if ( retVal == 0 )
        {
            // Allocate space for the PIM contact fields
            PIMname = new String[ PIMcontact_list.stringArraySize( javax.microedition.pim.Contact.NAME ) ];
            PIMaddress = new String[ PIMcontact_list.stringArraySize( javax.microedition.pim.Contact.ADDR ) ];

            // Read the PIM contacts
            try
            {
                PIMcontacts = PIMcontact_list.items();
            }
            catch ( PIMException ex )
            {
                e.setByName( "message", Constants.PIM_DATABASE_READING_ERROR + " " + ex.toString() );
                retVal = 1;
            }
        }

        // Store the all PIM contacts to model, which contain the needed mandatory fields
        if ( PIMcontacts != null && retVal == 0 )
        {
            while ( PIMcontacts.hasMoreElements() )
            {
                PIMcontact = (javax.microedition.pim.Contact) PIMcontacts.nextElement();

                contact = new Contact();

                copyFromPIMContact( PIMcontact, contact );

                if ( existsMandatoryFields( contact ) == true )
                {
                    contacts.addElement( contact );
                }
            }
        }

        // Close PIM contact database
        if ( retVal == 0 )
        {
            try
            {
                PIMcontact_list.close();
            }
            catch ( PIMException ex )
            {
                ex.printStackTrace();
                e.setByName( "message", Constants.PIM_DATABASE_CLOSING_ERROR + " " + ex.toString() );
                retVal = 1;
            }

            notifyObservers( "readContacts" );
        }

        return retVal;
    }

    //
    // Creates the PIM contact search criterion and PIM contact update values
    //
    private void createPIMContactSearchCriterion
    (
        ContactList PIMcontact_list,
        javax.microedition.pim.Contact PIMcontact_search,
        javax.microedition.pim.Contact PIMcontact_update,
        Contact contact
    )
    {
        String[] PIMname;
        String[] PIMaddress;


        // Allocate space for the PIM search contact fields
        PIMname = new String[ PIMcontact_list.stringArraySize( javax.microedition.pim.Contact.NAME ) ];
        PIMaddress = new String[ PIMcontact_list.stringArraySize( javax.microedition.pim.Contact.ADDR ) ];

        PIMname[ javax.microedition.pim.Contact.NAME_GIVEN ] = null;
        PIMname[ javax.microedition.pim.Contact.NAME_FAMILY ] = null;


        //
        // Store existing search criterion values to PIM search contact
        //

        if ( contact.getOriginal_first_name() != null )
        {
            if ( contact.getOriginal_first_name().length() > 0)
                PIMname[ javax.microedition.pim.Contact.NAME_GIVEN ] = contact.getOriginal_first_name();
        }
        else if ( contact.getFirst_name().length() > 0 )
        {
            PIMname[ javax.microedition.pim.Contact.NAME_GIVEN ] = contact.getFirst_name();
        }

        if ( contact.getOriginal_last_name() != null )
        {
            if ( contact.getOriginal_last_name().length() > 0 )
                PIMname[ javax.microedition.pim.Contact.NAME_FAMILY ] = contact.getOriginal_last_name();
        }
        else if ( contact.getLast_name().length() > 0 )
        {
            PIMname[ javax.microedition.pim.Contact.NAME_FAMILY ] = contact.getLast_name();
        }

        if ( PIMname[ javax.microedition.pim.Contact.NAME_GIVEN ] != null ||
             PIMname[ javax.microedition.pim.Contact.NAME_FAMILY ] != null )
        {
            PIMcontact_search.addStringArray( javax.microedition.pim.Contact.NAME, PIMItem.ATTR_NONE, PIMname );
        }

        if ( contact.getOriginal_company() != null )
        {
            if ( contact.getOriginal_company().length() > 0 )
                PIMcontact_search.addString( javax.microedition.pim.Contact.ORG, PIMItem.ATTR_NONE, contact.getOriginal_company() );
        }
        else if ( contact.getCompany().length() > 0 )
        {
            PIMcontact_search.addString( javax.microedition.pim.Contact.ORG, PIMItem.ATTR_NONE, contact.getCompany() );
        }


        // Allocate space for the PIM update contact fields
        PIMname = new String[ PIMcontact_list.stringArraySize( javax.microedition.pim.Contact.NAME ) ];
        PIMaddress = new String[ PIMcontact_list.stringArraySize( javax.microedition.pim.Contact.ADDR ) ];
        

        //
        // Store existing update values to PIM update contact
        //

        if ( contact.getAddress().length() > 0 )
        {
            PIMaddress[ javax.microedition.pim.Contact.ADDR_STREET ] = contact.getAddress();
            PIMcontact_update.addStringArray( javax.microedition.pim.Contact.ADDR, PIMItem.ATTR_NONE, PIMaddress );
        }

        if ( contact.getFirst_name().length() > 0 || contact.getLast_name().length() > 0 )
        {
            PIMname[ javax.microedition.pim.Contact.NAME_GIVEN ] = contact.getFirst_name();
            PIMname[ javax.microedition.pim.Contact.NAME_FAMILY ] = contact.getLast_name();
            PIMcontact_update.addStringArray( javax.microedition.pim.Contact.NAME, PIMItem.ATTR_NONE, PIMname );
        }

        if ( contact.getCompany().length() > 0 )
        {
            PIMcontact_update.addString( javax.microedition.pim.Contact.ORG, PIMItem.ATTR_NONE, contact.getCompany() );
        }

        if ( contact.getPhone().length() > 0 )
        {
            PIMcontact_update.addString( javax.microedition.pim.Contact.TEL, PIMItem.ATTR_NONE, contact.getPhone() );
        }
    }

    //
    // Returns true if the String type of field_id exists in PIM contact, otherwise false
    //
    //  PIMcontact  - PIM contact
    //
    //  field_id    - field id to check
    //
    private boolean existsPIMStringData
    (
        javax.microedition.pim.Contact PIMcontact,
        int field_id
    )
    {
        boolean retVal = false;

        if ( PIMcontact.countValues( field_id ) > 0 &&
             PIMcontact.getString( field_id, 0 ) != null &&
             PIMcontact.getString( field_id, 0 ).length() > 0 )
        {
            retVal = true;
        }

        return retVal;
    }

    //
    // Returns true if some of the String type of array field_ids exist in PIM contact, otherwise false
    //
    //  PIMcontact  - PIM contact
    //
    //  array_id    - array to check
    //
    //  field_id    - field ids of array to check
    //
    private boolean existsPIMArrayData
    (
        javax.microedition.pim.Contact PIMcontact,
        int array_id,
        Vector field_ids
    )
    {
        boolean retVal = false;
        int j;

        for ( j = 0; j < field_ids.size(); j++ )
        {
            s = (String) field_ids.elementAt( j );
            if ( PIMcontact.countValues( array_id ) > 0 &&
                 PIMcontact.getStringArray( array_id, 0 )[ Integer.parseInt( s ) ] != null &&
                 PIMcontact.getStringArray( array_id, 0 )[ Integer.parseInt( s ) ].length() > 0 )
            {
                retVal = true;
                break;
            }
        }

        return retVal;
    }

    //
    // Copies the PIM contact data from source to desstination
    //
    //  PIMcontact_dest     - destination PIM contact
    //
    //  PIMcontact_src      - source PIM contact
    //
    //  dest_data_exists    - true if the destination data exists, otherwise false
    //
    //  src_data_exists     - true if the source data exists, otherwise false
    //
    //  id                  - field id or array id to copy
    //
    //  data_type           - data type to copy, this can be "string" or "array"
    //
    private void copyPIMData
    (
        javax.microedition.pim.Contact PIMcontact_dest,
        javax.microedition.pim.Contact PIMcontact_src,
        boolean dest_data_exists,
        boolean src_data_exists,
        int id,
        String data_type
    )
    {
        String PIMdata_string_src = null;
        String[] PIMdata_array_src = null;

        // Get source data if it exists
        if ( src_data_exists == true )
        {
            if ( data_type.equals( "string" ) == true )
            {
                PIMdata_string_src = PIMcontact_src.getString( id, 0 );
            }
            else
            {
                PIMdata_array_src = PIMcontact_src.getStringArray( id, 0 );
            }
        }

        // If destination data exists
        if ( dest_data_exists == true )
        {
            // If the source data exists then copy it to destination, otherwise remove the destination data
            if ( src_data_exists == true )
            {
                if ( data_type.equals( "string" ) == true )
                {
                    PIMcontact_dest.setString
                    (
                        id,
                        0,
                        PIMItem.ATTR_NONE,
                        PIMdata_string_src
                    );
                }
                else
                {
                    PIMcontact_dest.setStringArray
                    (
                        id,
                        0,
                        PIMItem.ATTR_NONE,
                        PIMdata_array_src
                    );
                }
            }
            else
            {
                PIMcontact_dest.removeValue( id, 0 );
            }
        }
        // The destination data does not exist, so add the source data to destination if the source
        // data exists
        else if ( src_data_exists == true  )
        {
            if ( data_type.equals( "string" ) == true )
            {
                PIMcontact_dest.addString
                (
                    id,
                    javax.microedition.pim.Contact.ATTR_NONE,
                    PIMdata_string_src
                );
            }
            else
            {
                PIMcontact_dest.addStringArray
                (
                    id,
                    javax.microedition.pim.Contact.ATTR_NONE,
                    PIMdata_array_src
                );
            }
        }
    }

    //
    // Tries to search exact match from the PIM contact database
    // Returns the found PIM contact if the exact match was found, otherwise returns the
    // PIMcontact_update parameter
    //
    //  PIMcontacts         - contacts which has been read from the PIM database
    //
    //  PIMcontact_search   - PIM contact to search
    //
    //  PIMcontact_update   - PIM contact update values
    //
    private javax.microedition.pim.Contact searchPIMExactMatch
    (
        Enumeration PIMcontacts,
        javax.microedition.pim.Contact PIMcontact_search,
        javax.microedition.pim.Contact PIMcontact_update
    )
    {
        javax.microedition.pim.Contact PIMContact_tmp = null;
        Contact contact_to_search = new Contact();
        Contact contact_fetched = new Contact();
        boolean match_found = false;

        // If there are some found PIM contacts
        if ( PIMcontacts.hasMoreElements() == true )
        {
            // Get the contact to search
            copyFromPIMContact( PIMcontact_search, contact_to_search );

            // Loop through the PIM contacts
            while ( PIMcontacts.hasMoreElements() == true )
            {
                // Get the next PIM contact
                PIMContact_tmp = (javax.microedition.pim.Contact) PIMcontacts.nextElement();
                copyFromPIMContact( PIMContact_tmp, contact_fetched );

                // Check if the exact match was found
                if ( contact_fetched.getFirst_name().toUpperCase().equals( contact_to_search.getFirst_name().toUpperCase() ) == true &&
                     contact_fetched.getLast_name().toUpperCase().equals( contact_to_search.getLast_name().toUpperCase() ) == true &&
                     contact_fetched.getCompany().toUpperCase().equals( contact_to_search.getCompany().toUpperCase() ) == true )
                {
                    match_found = true;
                    break;
                }
            }
        }

        // Model contact already exists in the PIM contact database, so get it
        if ( match_found == true )
        {
            PIMcontact_search = PIMContact_tmp;
        }
        // Model contact does not exist in the PIM contact database, so use PIM update contact values
        else
        {
            PIMcontact_search = PIMcontact_update;
        }

        return PIMcontact_search;
    }

    //
    // Copies the values from the model contact to PIM contact and returns the updated PIM contact
    //
    private javax.microedition.pim.Contact copyToPIMContact
    (
        Enumeration PIMcontacts,
        javax.microedition.pim.Contact PIMcontact_search,
        javax.microedition.pim.Contact PIMcontact_update
    )
    {
        int field_id;
        int array_id;
        Vector field_ids;


        // Try to search exact match from the PIM contact database
        PIMcontact_search = searchPIMExactMatch( PIMcontacts, PIMcontact_search, PIMcontact_update );


        // Copy the name
        field_ids = new Vector();
        field_ids.addElement( javax.microedition.pim.Contact.NAME_GIVEN + "" );
        field_ids.addElement( javax.microedition.pim.Contact.NAME_FAMILY + "" );
        array_id = javax.microedition.pim.Contact.NAME;
        copyPIMData
        (
            PIMcontact_search,
            PIMcontact_update,
            existsPIMArrayData( PIMcontact_search, array_id, field_ids ),
            existsPIMArrayData( PIMcontact_update, array_id, field_ids ),
            array_id,
            "array"
        );


        // Copy the company
        field_id = javax.microedition.pim.Contact.ORG;
        copyPIMData
        (
            PIMcontact_search,
            PIMcontact_update,
            existsPIMStringData( PIMcontact_search, field_id ),
            existsPIMStringData( PIMcontact_update, field_id ),
            field_id,
            "string"
        );


        // Copy the address
        field_ids = new Vector();
        field_ids.addElement( javax.microedition.pim.Contact.ADDR_STREET + "" );
        array_id = javax.microedition.pim.Contact.ADDR;
        copyPIMData
        (
            PIMcontact_search,
            PIMcontact_update,
            existsPIMArrayData( PIMcontact_search, array_id, field_ids ),
            existsPIMArrayData( PIMcontact_update, array_id, field_ids ),
            array_id,
            "array"
        );


        // Copy the phone number
        field_id = javax.microedition.pim.Contact.TEL;
        copyPIMData
        (
            PIMcontact_search,
            PIMcontact_update,
            existsPIMStringData( PIMcontact_search, field_id ),
            existsPIMStringData( PIMcontact_update, field_id ),
            field_id,
            "string"
        );


        return PIMcontact_search;
    }

    //
    // Writes contacts into the PIM database and returns 0 if the writing was successful, otherwise 1
    // Returns the status message of writing in the Event parameter
    //
    public int writeContacts( Event e )
    {
        ContactList PIMcontact_list = null;
        javax.microedition.pim.Contact PIMcontact_search;
        javax.microedition.pim.Contact PIMcontact_update;
        Enumeration PIMcontacts = null;
        int retVal = 0;


        e.setByName( "message", Constants.PIM_DATABASE_WRITE_SUCCESSFUL );

        // Open the PIM contact database
        try
        {
            PIMcontact_list = (ContactList) PIM.getInstance().openPIMList
            (
                PIM.CONTACT_LIST,
                PIM.READ_WRITE
            );
        }
        catch ( PIMException ex )
        {
            e.setByName( "message", Constants.PIM_DATABASE_OPENING_ERROR + " " + ex.toString() );
            retVal = 1;
        }


        // If there are contacts in model and no error has occurred
        if ( getSize() > 0 && retVal == 0 )
        {

            // Loop through the contacts in model
            for ( i = 0; i < getSize() && retVal == 0; i++ )
            {
                // Get model contact
                contact = getContact( i );

                // Create PIM search and update contact
                PIMcontact_search = PIMcontact_list.createContact();
                PIMcontact_update = PIMcontact_list.createContact();


                // Create PIM contact search criterion and update data
                createPIMContactSearchCriterion
                (
                    PIMcontact_list,
                    PIMcontact_search,
                    PIMcontact_update,
                    contact
                );


                // Get contact data from the PIM contact database
                PIMcontacts = null;
                try
                {
                    PIMcontacts = PIMcontact_list.items( PIMcontact_search );
                }
                catch ( PIMException ex )
                {
                    e.setByName( "message", Constants.PIM_DATABASE_READING_ERROR + " " + ex.toString() );
                    retVal = 1;
                }


                if ( retVal == 0 )
                {
                    // Copy data from model contact to PIM contact
                    PIMcontact_search = copyToPIMContact
                    (
                        PIMcontacts,
                        PIMcontact_search,
                        PIMcontact_update
                    );

                    // Release the PIM update contact
                    PIMcontact_update = null;

                    // Commit changes to PIM contact database
                    try
                    {
                        PIMcontact_search.commit();
                        System.out.println( "Commit" );
                    }
                    catch ( PIMException ex )
                    {
                        e.setByName( "message", Constants.PIM_DATABASE_COMMIT_ERROR + " " + ex.toString() );
                        retVal = 1;
                    }
                }
            }
        }

        // Close PIM contact database
        try
        {
            PIMcontact_list.close();
        }
        catch ( PIMException ex )
        {
            e.setByName( "message", Constants.PIM_DATABASE_CLOSING_ERROR + " " + ex.toString() );
            retVal = 1;
        }

        if ( retVal == 0 )
        {
            // Open the PIM contact database
            try
            {
                PIMcontact_list = (ContactList) PIM.getInstance().openPIMList
                (
                    PIM.CONTACT_LIST,
                    PIM.READ_WRITE
                );
            }
            catch ( PIMException ex )
            {
                e.setByName( "message", Constants.PIM_DATABASE_OPENING_ERROR + " " + ex.toString() );
                retVal = 1;
            }
        }

        if ( retVal == 0 )
        {
            // Get contacts from PIM contact database
            PIMcontacts = null;
            try
            {
                PIMcontacts = PIMcontact_list.items();
            }
            catch ( PIMException ex )
            {
                e.setByName( "message", Constants.PIM_DATABASE_READING_ERROR + " " + ex.toString() );
                retVal = 1;
            }
        }

        // Loop through the contacts in PIM contact database and delete all contacts,
        // which does not exist in model, PIM contact must contain the needed mandatory fields, otherwise it will be skipped
        if ( retVal == 0 && PIMcontacts != null && PIMcontacts.hasMoreElements() )
        {
            contact = new Contact();
            index = -1;

            while ( PIMcontacts.hasMoreElements() && retVal == 0 )
            {
                PIMcontact_search = (javax.microedition.pim.Contact) PIMcontacts.nextElement();

                copyFromPIMContact( PIMcontact_search, contact );

                if ( existsMandatoryFields( contact ) && existsContact( contact ) == false )
                {
                    try
                    {
                        System.out.println( "remove" );
                        PIMcontact_list.removeContact( PIMcontact_search );
                    }
                    catch ( PIMException ex )
                    {
                        e.setByName( "message", Constants.PIM_DATABASE_REMOVING_ERROR + " " + ex.toString() );
                        retVal = 1;
                    }
                }
            }
        }

        if ( retVal == 0 )
        {
            // Close PIM contact database
            try
            {
                PIMcontact_list.close();
            }
            catch ( PIMException ex )
            {
                e.setByName( "message", Constants.PIM_DATABASE_CLOSING_ERROR + " " + ex.toString() );
                retVal = 1;                
            }
        }

        return retVal;
    }
}
