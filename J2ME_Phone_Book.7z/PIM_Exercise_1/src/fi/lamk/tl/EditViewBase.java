//
// EditViewBase class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.TextField;

/**
 *
 * @author virtajou
 *
 * EditViewBase class inherits the View class and implements the CommandListener and Observer interfaces
 * 
 */
public class EditViewBase extends View implements CommandListener, Observer {

    // Define protected member variables for the EditViewBase class
    protected TextField first_name_field;
    protected TextField last_name_field;
    protected TextField company_name_field;
    protected TextField address_field;
    protected TextField phone_field;

    protected Command exitCommand;
    protected Command saveCommand;

    protected Contact contact;

    //
    // Default constructor for the EditViewBase class
    //
    public EditViewBase( String title, String name, Display display )
    {
        super( title, name, display );

        // Add commands into the view and create the needed view fields
        
        exitCommand = new Command( Constants.EXIT_COMMAND_LABEL, Command.EXIT, 1 );
        this.addCommand( exitCommand );

        saveCommand = new Command( Constants.SAVE_COMMAND_LABEL, Command.SCREEN, 1 );
        this.addCommand( saveCommand );

        first_name_field = new TextField( Constants.FIRST_NAME_STRING, "", 30, TextField.ANY );
        first_name_field.setLayout( Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT );

        last_name_field = new TextField( Constants.LAST_NAME_STRING, "", 30, TextField.ANY );
        last_name_field.setLayout( Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT );

        company_name_field = new TextField( Constants.COMPANY_NAME_STRING, "", 30, TextField.ANY );
        company_name_field.setLayout( Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT );

        phone_field = new TextField( Constants.PHONE_STRING, "", 30, TextField.PHONENUMBER );
        phone_field.setLayout( Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT );
        
        address_field = new TextField( Constants.ADDRESS_STRING, "", 30, TextField.ANY );
        address_field.setLayout( Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT );

        // Set this class as a CommandListener implementer
        this.setCommandListener( this );
    }

    public void commandAction( Command c, Displayable d )
    {

    }

    //
    // Returns true if the mandatory fields exist in the view, otherwise false
    //
    public boolean checkMandatoryFields()
    {
        boolean retVal = true;

        // Remove all leading and trailing spaces from the fields
        first_name_field.setString( first_name_field.getString().trim() );
        last_name_field.setString( last_name_field.getString().trim() );
        company_name_field.setString( company_name_field.getString().trim() );
        address_field.setString( address_field.getString().trim() );

        contact = new Contact();
        contact.setFirst_name( first_name_field.getString() );
        contact.setLast_name( last_name_field.getString() );
        contact.setCompany( company_name_field.getString() );
        
        event = new Event();
        event.setByName( "contact", contact );

        if ( controller.handleEvent( Event.CHECK_MANDATORY_FIELDS, event) == false )
        {
            Public.showMessage
            (
                Constants.ERROR_STRING,
                Constants.MANDATORY_DATA_MISSING_STRING,
                display
            );
            retVal = false;
        }


        return retVal;
    }

    public void update( Observable o, String arg )
    {

        // Delete all items of the view
        this.deleteAll();

        // Append the needed items into the view

        Public.appendStringItemToForm
        (
            "",
            Constants.DASH_LINE + " " + Constants.CONTACT_STRING + arg + " " + Constants.DASH_LINE + "\n",
            Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_LEFT,
            this,
            -1
        );

        this.append( first_name_field );
        this.append( last_name_field );
        this.append( company_name_field );
        this.append( phone_field );
        this.append( address_field );
    }

}
