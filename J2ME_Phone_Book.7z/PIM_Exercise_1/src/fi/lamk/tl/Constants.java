//
// Constants class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;

/**
 *
 * @author virtajou
 *
 * Constants class
 * 
 */
public class Constants {

    // Constants

    public static final String MAIN_MENU_TITLE = "Make your selection";
    public static final String LIST_MENU_TITLE = "Select contact to edit";
    public static final String DELETE_MENU_TITLE = "Select contact to delete";
    public static final String EDIT_VIEW_TITLE = "Edit contact";
    public static final String APPEND_VIEW_TITLE = "Add contact";

    public static final String EXIT_COMMAND_LABEL = "Exit";
    public static final String SAVE_COMMAND_LABEL = "Save";
    public static final String EDIT_COMMAND_LABEL = "Edit";
    public static final String DELETE_COMMAND_LABEL = "Delete";
    public static final String OK_COMMAND_LABEL = "OK";
    public static final String BACK_COMMAND_LABEL = "Back";

    public static final String DASH_LINE = "--------";
    public static final String DASH_LINE_LONG = "----------------------------";
    public static final String CONTACT_STRING = "Contact ";
    public static final String FIRST_NAME_STRING = "First name: ";
    public static final String LAST_NAME_STRING = "Last name: ";
    public static final String COMPANY_NAME_STRING = "Company name: ";
    public static final String ADDRESS_STRING = "Address: ";
    public static final String PHONE_STRING = "Phone: ";
    
    public static final String ERROR_STRING = "Error";
    public static final String INFO_STRING = "Info";

    public static final String CONTACT_ALREADY_EXISTS_STRING = "This contact already exists, please change the first name or the last name or the company name.";
    public static final String MANDATORY_DATA_MISSING_STRING = "Mandatory data is missing, please enter the first name or the last name or the company name.";
    public static final String CONTACT_SAVED_STRING = "Contact saved.";
    public static final String CONTACT_ADDED_STRING = "Contact added.";
    public static final String DELETE_CONFIRM_STRING = "Do you want to delete contact";

    public static final String PIM_DATABASE_OPENING_ERROR = "Opening of PIM database failed.";
    public static final String PIM_DATABASE_READING_ERROR = "Reading of PIM database failed.";
    public static final String PIM_DATABASE_CLOSING_ERROR = "Closing of PIM database failed.";
    public static final String PIM_DATABASE_REMOVING_ERROR = "Removing of contact from PIM database failed.";
    public static final String PIM_DATABASE_COMMIT_ERROR = "Commit of PIM database failed.";
    public static final String PIM_DATABASE_READ_SUCCESSFUL = "Reading of PIM database was successful.";
    public static final String PIM_DATABASE_WRITE_SUCCESSFUL = "Writing of PIM database was successful.";
}
