//
// Observer interface.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


/**
 *
 * @author virtajou
 *
 * Observer interface
 * 
 */
public interface Observer {

    public void update( Observable o, String arg );
}
