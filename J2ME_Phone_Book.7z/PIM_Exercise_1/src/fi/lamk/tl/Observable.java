//
// Observable class.
//
// Developed by Jouni Virtanen / LAMK / TIEIA08
//
// 2.8.2011
//


// Define the application package
package fi.lamk.tl;


// Import the needed classes for the application
import java.util.Enumeration;
import java.util.Hashtable;


/**
 *
 * @author virtajou
 *
 * Observable class
 *
 */
public class Observable {

    // Define protected member variables for the Observable class
    protected Hashtable setOfObservers;

    // Define private member variables for the Observable class
    private Enumeration e;


    //
    // Default constructor for the Observable class
    //
    public Observable()
    {
        setOfObservers = new Hashtable();
    }

    //
    // Adds a new observer to the setOfObservers vector
    //
    //  observer    - observer to add
    //
    //  name        - observer name
    //
    public void attachObserver( Object observer, String name )
    {
        setOfObservers.put( name, observer );
    }

    //
    // Removes an observer from the setOfObservers vector
    //
    //  name    - observer name
    //
    public void detachObserver( String name )
    {
        setOfObservers.remove( name );
    }

    //
    // Calls the update method of all observers
    //
    //  arg - argument to pass for the observers' update method
    //
    public void notifyObservers( String arg )
    {

        for ( e = setOfObservers.elements(); e.hasMoreElements(); )
        {
            Observer o = (Observer) e.nextElement();

            o.update( this, arg );
        }
    }

    //
    // Returns an observer from the setOfObservers vector
    //
    //  name    - observer name
    //
    public Object getObserver( String name )
    {
        return setOfObservers.get( name );
    }
}
